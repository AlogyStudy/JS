# facetype.js
typeface.js generator

Useful for text in Three.js
